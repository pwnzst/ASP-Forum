﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Chat.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            Models.ChatContext chat = new Models.ChatContext();
            int n = chat.Users.Count();
            ViewBag.UserCount = n;
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ActionResult Registration()
        {
            ViewBag.Message = "Registration page.";

            return View();
        }

        public ActionResult RegUser(Models.User user)
        {
            if (!String.IsNullOrEmpty(user.Login))
            {
                var sb = new System.Text.StringBuilder();
                var rnd = new Random();
                for (int i = 0; i < 32; i++)
                {
                    sb.Append(((byte)rnd.Next()).ToString("X2"));
                }
                user.PassSalt = sb.ToString();
                user.PassHash = Utils.GetSHA256HexString(user.PassHash + user.PassSalt);
                user.Registered = DateTime.Now;

                Models.ChatContext chat = new Models.ChatContext();
                chat.Users.Add(user);
                chat.SaveChanges();
            }
            ViewBag.User = user;

            return View();
        }
    }
}